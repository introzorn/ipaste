@extends('html')
@section('main-title')О сервисе пасты@endsection

@section('content')

    @include('head')

<div>Тут какойто текст</div>

    @include('footer')

@endsection
