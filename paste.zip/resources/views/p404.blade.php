@extends('html')
@section('main-title')О сервисе пасты@endsection

@section('content')

    @include('head')

<div class="abstractcont">
<br><br>
    <div class="tablo" >
        <div class="row">
            <div class="col p404" style=""> </div>
            <div class="col-7" style="color:rgb(16, 0, 160)" ><b style="font-size: 90pt"> 404</b> <b style="font-size: 18pt;  white-space: nowrap;">страница не существует</b><br><br></div>

        </div>


    </div>

</div>

    @include('footer')

@endsection
