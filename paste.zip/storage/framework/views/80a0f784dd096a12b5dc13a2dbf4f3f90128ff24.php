<?php $__env->startSection('main-title'); ?><?php echo e($pdata->name); ?><?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container cont1">
<div class="row"><div class="col-9"><!-- основной блок-->




   <h3 style="text-align:center"  class="h44"> <?php echo e($pdata->name); ?> </h3>



    <div class="row">
<?php if($pdata->user): ?>
<div class="col-sm" >
<h5  class="h44">Автор: <?php echo e($pdata->user); ?></h4>
</div>
<?php endif; ?>


        <div class="col-sm">

 <h5  class="h44">Тип кода: <?php echo e(mb_strtoupper(pcont::PLtoTXT($pdata->codetype))); ?></h4>
        </div>
        <div class="col-sm">
 <h5  class="h44">Доступна: <?php echo e($extime); ?></h4>
        </div>
    </div>



 <pre id="hlight" class="brush: <?php echo e($pdata->codetype); ?>" ><?php echo e($pdata->code); ?></pre>


<div class="input-group mb-3">
    <span class="input-group-text" id="basic-addon1">Урл адресс пасты :</span>
    <input type="text" class="form-control"  aria-label="Урл адресс пасты" aria-describedby="basic-addon1" name="url" id="url" value="<?php echo e(Request::url()); ?>" readonly>
  </div>


</div>
<div class="col-3"> <!-- боковой блок -->

<?php echo $__env->make('rblock', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
</div>







    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WAMP\vhosts\introzorn.co\paste\resources\views/pasta.blade.php ENDPATH**/ ?>