
<?php if(Auth::Check()): ?>
<div class="alert alert-dark larg" style="margin-top:10px; background-color:rgb(4, 33, 95); color: white;" >Мои новые пасты:</div>


<?php $__currentLoopData = pcont::getMyLastPaste(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mpasta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="alert btn-light" role="alert" style="padding:5px!important; margin: 2px">
   <div style="text-overflow: ellipsis;font-size:10pt; width:100%; overflow:hidden; white-space: nowrap;"> <b><?php echo e($mpasta->name); ?></b></div>

    <div class="row">
        <div class="col-sm " style="font-size:8.5pt;white-space: nowrap;">


            Дата создания: <?php echo e(date("d.m.Y",$mpasta->utime)); ?><br>
           <span class="vcol<?php echo e($mpasta->view); ?>">Паста <?php echo e(pcont::$ViewTEXT[$mpasta->view]); ?>/<?php echo e(pcont::PLtoTXT($mpasta->codetype)); ?></span>


        </div>
        <div class="col-sm">
          <a class="btn btn-sm btn-primary" style="float:right; margin:10px" href="<?php echo e(route('alias',$mpasta->alias)); ?>" role="button">Посмотреть»</a>
        </div>
    </div>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php endif; ?>


<div class="alert alert-dark larg" style="margin-top:10px; background-color:dimgray; color: white;" >последние <?php if(Auth::Check()): ?><?php echo e(4); ?><?php else: ?><?php echo e(10); ?><?php endif; ?> паст:</div>
<?php $__currentLoopData = pcont::getLastPaste(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpasta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="alert alert-dark" role="alert" style="padding:5px!important; margin: 2px">
   <div style="text-overflow: ellipsis;font-size:10pt; width:100%; overflow:hidden; white-space: nowrap;"> <b><?php echo e($lpasta->name); ?></b></div>

    <div class="row">
        <div class="col-sm " style="font-size:8.5pt;white-space: nowrap;">
            <?php if($lpasta->user!=''): ?>
             Пользователь: <?php echo e($lpasta->user); ?> <br>
            <?php endif; ?>

            Дата создания: <?php echo e(date("d.m.Y",$lpasta->utime)); ?><br>
            Тип Пасты: <?php echo e($lpasta->codetype); ?>



        </div>
        <div class="col-sm">
          <a class="btn btn-sm btn-primary" style="float:right; margin:10px" href="<?php echo e(route('alias',$lpasta->alias)); ?>" role="button">Посмотреть»</a>
        </div>
    </div>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\WAMP\vhosts\introzorn.co\paste\resources\views/rblock.blade.php ENDPATH**/ ?>