<?php $__env->startSection('main-title'); ?>Сервис Пасты - куски кода в удобной обёртке<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container cont1">
<div class="row"><div class="col-9 bl-ver"><!-- основной блок-->
<h3 class="h44">Все Пасты проекта :</h3>
    <?php $__currentLoopData = $allpasta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpasta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="alert alert-light border border-secondary" role="alert" style="padding:5px!important; box-shadow:0 0 5px rgb(155, 155, 155)">
        <b><?php echo e($lpasta->name); ?></b>
             <pre id="hlight2" class="brush: <?php echo e($lpasta->codetype); ?>" >
             <?php echo e(pcont::ShtPasta($lpasta->code)); ?>

            </pre>
        <div class="row">
            <div class="col-sm">


                Дата создания: <?php echo e(date("d.m.Y",$lpasta->utime)); ?><br>
                Тип Пасты: <?php echo e(pcont::PLtoTXT($lpasta->codetype)); ?>



            </div>
            <div class="col-sm">
                <?php if($lpasta->user!=''): ?>
                 Автор: <?php echo e($lpasta->user); ?> <br>
                <?php endif; ?>
            </div>
            <div class="col-sm">
              <a class="btn btn-primary" style="float:right; margin:10px" href="<?php echo e(route('alias',$lpasta->alias)); ?>" role="button">Посмотреть»</a>
            </div>
        </div>

    </div>



    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<center>
    <div style="display:block; width:max-content">
 <?php echo e($allpasta->links()); ?>

    </div>
</center>
</div>
<div class="col-3 bl-ver"> <!-- боковой блок -->

<?php echo $__env->make('rblock', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
</div>




    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WAMP\vhosts\introzorn.co\paste\resources\views/main.blade.php ENDPATH**/ ?>