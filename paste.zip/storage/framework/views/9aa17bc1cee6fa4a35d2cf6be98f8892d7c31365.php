<?php $__env->startSection('main-title'); ?>О сервисе пасты<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="abstractcont">
<br><br>
    <div class="tablo" style="width:400px;padding-left:30px; padding-right:30px;" >
        <form action="<?php echo e(route('reg')); ?>" method="POST">

            <h4>Регистрация пользователя</h4>

<?php echo csrf_field(); ?>
                <span >Логин:</span>
                <input type="text" name="user" class="form-control mt-1" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg">


                <span  >Пароль:</span>
                <input type="password" name="password" class="form-control mt-1" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg">


                <span  >Подтвердить:</span>
                <input type="password" name="password_confirmation" class="form-control mt-1" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg">

                <button type="submit" class="btn btn-primary mt-3 " style="width:100%">Зарегистрироваться</button>
<br>



                <?php $__errorArgs = ['user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger" style="padding:0 20px 0 20px; margin:5px; ">
                Логин должен быть длиннее 5 символов и состоять из латинских букв и цифр.
                Хотя возможно такой логин существует . но это не точно =)
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger" style="padding:0 20px 0 20px; margin:5px">
                    Пароль должен быть больше 5 символов
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger" style="padding:0 20px 0 20px; margin:5px">
                    Пароли не совпадают
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>


        </form>

    </div>

</div>

    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WAMP\vhosts\introzorn.co\paste\resources\views/reg.blade.php ENDPATH**/ ?>