<?php $__env->startSection('main-title'); ?>Войти в учетную запись<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="abstractcont">
<br><br>
    <div class="tablo" style="width:400px;padding-left:30px; padding-right:30px;" >
        <form action="<?php echo e(route('login')); ?>" method="POST">

            <h4> Авторизация пользователя</h4>

<?php echo csrf_field(); ?>
                <span >Логин:</span>
                <input type="text" name="user" class="form-control mt-1" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg">


                <span  >Пароль:</span>
                <input type="password" name="password" class="form-control mt-1" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg">



                <button type="submit" class="btn btn-primary mt-3 " style="width:100%">Войти</button>
<br>
                <?php if(count( $errors ) > 0): ?>
                <div class="alert alert-danger" style="padding:0 20px 0 20px; margin:5px; ">

                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <b> <?php echo e($error); ?></b><br>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                Неверный логин или пароль
                </div>
                <?php endif; ?>

                <br>


        </form>

    </div>

</div>

    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WAMP\vhosts\introzorn.co\paste\resources\views/login.blade.php ENDPATH**/ ?>