<div class="shapka">



    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="z-index:-1;margin:auto;background:rgb(241, 241, 241);display:block;position:absolute" width="100%" height="500" preserveAspectRatio="xMidYMid" viewBox2="0 0 100% 900">
        <g transform="translate(802,133.5) scale(1,1) translate(-802,-133.5)"><defs><filter id="blur-z0txlnb2qn-1" x="-1" y="-1" width="3" height="3">
          <feGaussianBlur stdDeviation="3"></feGaussianBlur>
        </filter><filter id="blur-z0txlnb2qn-2" x="-1" y="-1" width="3" height="3">
          <feGaussianBlur stdDeviation="1.5"></feGaussianBlur>
        </filter><filter id="blur-z0txlnb2qn-3" x="-1" y="-1" width="3" height="3">
          <feGaussianBlur stdDeviation="1"></feGaussianBlur>
        </filter></defs><circle cx="486.5474833748036" cy="0" transform="translate(0 189.15394423324202)" r="236.9827365109183" fill="#ddeeff" opacity="0.7200000000000001">
          <animateTransform attributeName="transform" type="translate" begin="-72.02900578305099s" dur="111.1111111111111s" repeatCount="indefinite" keyTimes="0;1" values="0 503.9827365109183;0 -236.9827365109183"></animateTransform>
        </circle><circle cx="1589.3125163194175" cy="0" transform="translate(0 82.722726152943)" r="200.2697334876551" fill="#ddeeff" opacity="0.7200000000000001">
          <animateTransform attributeName="transform" type="translate" begin="-31.250713931594778s" dur="111.1111111111111s" repeatCount="indefinite" keyTimes="0;1" values="0 467.2697334876551;0 -200.2697334876551"></animateTransform>
        </circle><circle cx="739.3988225929337" cy="0" transform="translate(0 156.26966488178994)" r="137.55837377440884" fill="#ddeeff" opacity="0.63">
          <animateTransform attributeName="transform" type="translate" begin="-111.39678489277722s" dur="166.66666666666666s" repeatCount="indefinite" keyTimes="0;1" values="0 404.55837377440884;0 -137.55837377440884"></animateTransform>
        </circle><circle cx="484.0187581197353" cy="0" transform="translate(0 44.106731154092955)" r="143.12659027122072" fill="#005ab4" opacity="0.63">
          <animateTransform attributeName="transform" type="translate" begin="-76.45088180773477s" dur="166.66666666666666s" repeatCount="indefinite" keyTimes="0;1" values="0 410.1265902712207;0 -143.12659027122072"></animateTransform>
        </circle><circle cx="962.5490764914405" cy="0" transform="translate(0 226.27161561727618)" r="192.99813994263283" fill="#005ab4" opacity="0.63">
          <animateTransform attributeName="transform" type="translate" begin="-50.41531292922107s" dur="166.66666666666666s" repeatCount="indefinite" keyTimes="0;1" values="0 459.99813994263286;0 -192.99813994263283"></animateTransform>
        </circle><circle cx="772.0781221781258" cy="0" transform="translate(0 216.82145769072145)" r="115.49385195240015" fill="#ddeeff" opacity="0.36000000000000004">
          <animateTransform attributeName="transform" type="translate" begin="-278.78794765616385s" dur="333.3333333333333s" repeatCount="indefinite" keyTimes="0;1" values="0 382.4938519524002;0 -115.49385195240015"></animateTransform>
        </circle><circle cx="0.8388402899139287" cy="0" transform="translate(0 102.5326707094477)" r="230.19562281317386" fill="#005ab4" opacity="0.7200000000000001">
          <animateTransform attributeName="transform" type="translate" begin="-97.34490540127281s" dur="111.1111111111111s" repeatCount="indefinite" keyTimes="0;1" values="0 497.1956228131738;0 -230.19562281317386"></animateTransform>
        </circle><circle cx="54.78251037888296" cy="0" transform="translate(0 80.65602910848578)" r="206.2832267811774" fill="#8dc6ff" opacity="0.7200000000000001">
          <animateTransform attributeName="transform" type="translate" begin="-54.86886469050116s" dur="111.1111111111111s" repeatCount="indefinite" keyTimes="0;1" values="0 473.2832267811774;0 -206.2832267811774"></animateTransform>
        </circle><circle cx="1411.6435428829925" cy="0" transform="translate(0 9.635669386835854)" r="229.6214353757906" fill="#005ab4" opacity="0.7200000000000001">
          <animateTransform attributeName="transform" type="translate" begin="-23.77872929487649s" dur="111.1111111111111s" repeatCount="indefinite" keyTimes="0;1" values="0 496.6214353757906;0 -229.6214353757906"></animateTransform>
        </circle><circle cx="160.20895139581071" cy="0" transform="translate(0 145.08523320600673)" r="209.72077026677522" fill="#ddeeff" opacity="0.7200000000000001">
          <animateTransform attributeName="transform" type="translate" begin="-47.46436426693903s" dur="111.1111111111111s" repeatCount="indefinite" keyTimes="0;1" values="0 476.7207702667752;0 -209.72077026677522"></animateTransform>
        </circle><circle cx="1599.4195980752233" cy="0" transform="translate(0 11.163373359497607)" r="143.84886026206536" fill="#8dc6ff" opacity="0.63">
          <animateTransform attributeName="transform" type="translate" begin="-53.560750166448045s" dur="166.66666666666666s" repeatCount="indefinite" keyTimes="0;1" values="0 410.8488602620654;0 -143.84886026206536"></animateTransform>
        </circle><circle cx="151.72375418451273" cy="0" transform="translate(0 107.66962856353545)" r="136.4631371925237" fill="#ddeeff" opacity="0.63">
          <animateTransform attributeName="transform" type="translate" begin="-53.108756626575804s" dur="166.66666666666666s" repeatCount="indefinite" keyTimes="0;1" values="0 403.46313719252373;0 -136.4631371925237"></animateTransform>
        </circle><circle cx="211.82112045006073" cy="0" transform="translate(0 208.88977514006007)" r="206.41798806241485" fill="#ddeeff" opacity="0.7200000000000001">
          <animateTransform attributeName="transform" type="translate" begin="-53.080129218232s" dur="111.1111111111111s" repeatCount="indefinite" keyTimes="0;1" values="0 473.41798806241485;0 -206.41798806241485"></animateTransform>
        </circle><circle cx="272.53916655706524" cy="0" transform="translate(0 4.432522222186395)" r="127.32577792755957" fill="#005ab4" opacity="0.36000000000000004">
          <animateTransform attributeName="transform" type="translate" begin="-323.2424014527147s" dur="333.3333333333333s" repeatCount="indefinite" keyTimes="0;1" values="0 394.32577792755956;0 -127.32577792755957"></animateTransform>
        </circle><circle cx="122.42442650504539" cy="0" transform="translate(0 6.981805347501307)" r="179.1819477702716" fill="#ddeeff" opacity="0.63">
          <animateTransform attributeName="transform" type="translate" begin="-27.88736357413061s" dur="166.66666666666666s" repeatCount="indefinite" keyTimes="0;1" values="0 446.18194777027156;0 -179.1819477702716"></animateTransform>
        </circle><circle cx="73.97661062875102" cy="0" transform="translate(0 151.39352412791382)" r="153.0975907527632" fill="#8dc6ff" opacity="0.63">
          <animateTransform attributeName="transform" type="translate" begin="-156.87030347359553s" dur="166.66666666666666s" repeatCount="indefinite" keyTimes="0;1" values="0 420.0975907527632;0 -153.0975907527632"></animateTransform>
        </circle><circle cx="955.373301455006" cy="0" transform="translate(0 204.64982481759816)" r="239.79508005341233" fill="#8dc6ff" opacity="0.7200000000000001">
          <animateTransform attributeName="transform" type="translate" begin="-107.4001594681883s" dur="111.1111111111111s" repeatCount="indefinite" keyTimes="0;1" values="0 506.79508005341233;0 -239.79508005341233"></animateTransform>
        </circle><circle cx="322.98151394293586" cy="0" transform="translate(0 70.63365014526275)" r="155.82907799129669" fill="#8dc6ff" opacity="0.63">
          <animateTransform attributeName="transform" type="translate" begin="-95.92084849045398s" dur="166.66666666666666s" repeatCount="indefinite" keyTimes="0;1" values="0 422.8290779912967;0 -155.82907799129669"></animateTransform>
        </circle><circle cx="283.97484413888077" cy="0" transform="translate(0 71.20351878879785)" r="259.6897860261172" fill="#005ab4" opacity="0.7200000000000001">
          <animateTransform attributeName="transform" type="translate" begin="-40.129228520935065s" dur="111.1111111111111s" repeatCount="indefinite" keyTimes="0;1" values="0 526.6897860261172;0 -259.6897860261172"></animateTransform>
        </circle><circle cx="245.0696940737907" cy="0" transform="translate(0 181.163988323209)" r="194.12786730273444" fill="#ddeeff" opacity="0.63">
          <animateTransform attributeName="transform" type="translate" begin="-19.396753290539767s" dur="166.66666666666666s" repeatCount="indefinite" keyTimes="0;1" values="0 461.12786730273444;0 -194.12786730273444"></animateTransform>
        </circle><circle cx="1465.3656843820118" cy="0" transform="translate(0 28.985008000712458)" r="264.3499135021943" fill="#005ab4" opacity="0.7200000000000001">
          <animateTransform attributeName="transform" type="translate" begin="-104.0218403416777s" dur="111.1111111111111s" repeatCount="indefinite" keyTimes="0;1" values="0 531.3499135021943;0 -264.3499135021943"></animateTransform>
        </circle><circle cx="121.14213560946729" cy="0" transform="translate(0 173.10699512354577)" r="71.30080879003738" fill="#8dc6ff" opacity="0.36000000000000004">
          <animateTransform attributeName="transform" type="translate" begin="-320.2166508830763s" dur="333.3333333333333s" repeatCount="indefinite" keyTimes="0;1" values="0 338.30080879003737;0 -71.30080879003738"></animateTransform>
        </circle><circle cx="627.4471046039505" cy="0" transform="translate(0 96.96547469196305)" r="110.13450233426676" fill="#ddeeff" opacity="0.36000000000000004">
          <animateTransform attributeName="transform" type="translate" begin="-92.91631509073794s" dur="333.3333333333333s" repeatCount="indefinite" keyTimes="0;1" values="0 377.13450233426676;0 -110.13450233426676"></animateTransform>
        </circle><circle cx="134.39645453147108" cy="0" transform="translate(0 60.10799417990485)" r="183.22748530528972" fill="#005ab4" opacity="0.63">
          <animateTransform attributeName="transform" type="translate" begin="-105.25785949404376s" dur="166.66666666666666s" repeatCount="indefinite" keyTimes="0;1" values="0 450.22748530528975;0 -183.22748530528972"></animateTransform>
        </circle><circle cx="1482.6888918607267" cy="0" transform="translate(0 185.86738746592772)" r="167.65446032728667" fill="#8dc6ff" opacity="0.63">
          <animateTransform attributeName="transform" type="translate" begin="-11.29706273569242s" dur="166.66666666666666s" repeatCount="indefinite" keyTimes="0;1" values="0 434.65446032728664;0 -167.65446032728667"></animateTransform>
        </circle><circle cx="141.71502169908555" cy="0" transform="translate(0 227.14354254621531)" r="131.5969930194598" fill="#ddeeff" opacity="0.36000000000000004">
          <animateTransform attributeName="transform" type="translate" begin="-120.21861866305287s" dur="333.3333333333333s" repeatCount="indefinite" keyTimes="0;1" values="0 398.5969930194598;0 -131.5969930194598"></animateTransform>
        </circle><circle cx="456.36201504778313" cy="0" transform="translate(0 12.296999566665377)" r="146.45091679042451" fill="#8dc6ff" opacity="0.63">
          <animateTransform attributeName="transform" type="translate" begin="-62.33827123313029s" dur="166.66666666666666s" repeatCount="indefinite" keyTimes="0;1" values="0 413.4509167904245;0 -146.45091679042451"></animateTransform>
        </circle><circle cx="278.6457920502286" cy="0" transform="translate(0 144.2462561437318)" r="160.82025462089314" fill="#8dc6ff" opacity="0.63">
          <animateTransform attributeName="transform" type="translate" begin="-151.46042601784117s" dur="166.66666666666666s" repeatCount="indefinite" keyTimes="0;1" values="0 427.82025462089314;0 -160.82025462089314"></animateTransform>
        </circle><circle cx="1546.4007100387314" cy="0" transform="translate(0 33.91263406115357)" r="84.79040976585856" fill="#8dc6ff" opacity="0.36000000000000004">
          <animateTransform attributeName="transform" type="translate" begin="-254.27923859355727s" dur="333.3333333333333s" repeatCount="indefinite" keyTimes="0;1" values="0 351.79040976585856;0 -84.79040976585856"></animateTransform>
        </circle><circle cx="1071.4148103539014" cy="0" transform="translate(0 140.53772821902817)" r="166.46265476480897" fill="#ddeeff" opacity="0.63">
          <animateTransform attributeName="transform" type="translate" begin="-141.52849087088012s" dur="166.66666666666666s" repeatCount="indefinite" keyTimes="0;1" values="0 433.462654764809;0 -166.46265476480897"></animateTransform>
        </circle><circle cx="501.878307194112" cy="0" transform="translate(0 240.7734491786702)" r="206.10641294163844" fill="#8dc6ff" opacity="0.7200000000000001">
          <animateTransform attributeName="transform" type="translate" begin="-66.40006901825998s" dur="111.1111111111111s" repeatCount="indefinite" keyTimes="0;1" values="0 473.10641294163844;0 -206.10641294163844"></animateTransform>
        </circle><circle cx="1526.7977836873997" cy="0" transform="translate(0 259.85813371846825)" r="123.15233891616965" fill="#8dc6ff" opacity="0.36000000000000004">
          <animateTransform attributeName="transform" type="translate" begin="-195.39423957614773s" dur="333.3333333333333s" repeatCount="indefinite" keyTimes="0;1" values="0 390.15233891616964;0 -123.15233891616965"></animateTransform>
        </circle><circle cx="1202.437433761643" cy="0" transform="translate(0 155.6794665671331)" r="220.80017161282439" fill="#ddeeff" opacity="0.7200000000000001">
          <animateTransform attributeName="transform" type="translate" begin="-20.19492595482111s" dur="111.1111111111111s" repeatCount="indefinite" keyTimes="0;1" values="0 487.8001716128244;0 -220.80017161282439"></animateTransform>
        </circle><circle cx="339.7862011551457" cy="0" transform="translate(0 115.57740524639432)" r="178.57836870773454" fill="#005ab4" opacity="0.63">
          <animateTransform attributeName="transform" type="translate" begin="-14.527516760150219s" dur="166.66666666666666s" repeatCount="indefinite" keyTimes="0;1" values="0 445.5783687077345;0 -178.57836870773454"></animateTransform>
        </circle><circle cx="647.8466041883578" cy="0" transform="translate(0 263.5993832649361)" r="136.75851004237495" fill="#005ab4" opacity="0.63">
          <animateTransform attributeName="transform" type="translate" begin="-74.74563373347213s" dur="166.66666666666666s" repeatCount="indefinite" keyTimes="0;1" values="0 403.75851004237495;0 -136.75851004237495"></animateTransform>
        </circle><circle cx="1325.2079832462357" cy="0" transform="translate(0 96.128059531876)" r="248.20007162865144" fill="#005ab4" opacity="0.7200000000000001">
          <animateTransform attributeName="transform" type="translate" begin="-67.26092522674512s" dur="111.1111111111111s" repeatCount="indefinite" keyTimes="0;1" values="0 515.2000716286515;0 -248.20007162865144"></animateTransform>
        </circle></g>
        </svg>



<div style="position:absolute; display:block; z-index:-1; margin:auto; left:0px; bottom:-350px; width:100%; height:200px; background-image: linear-gradient(rgb(241, 241, 241,0), rgba(241,241,241));">
</div>





  <div style="position:absolute; display:block; z-index:1; margin:auto; right:20px; top:50px;">
<div style="text-align:right" class="link-light fs-6 ">


<?php if(Auth::Check()): ?>
<b class="link-light fs-6 btn3"><?php echo e(Auth::User()->user); ?></b> ||
<a href="<?php echo e(route('logout')); ?>" class="link-light fs-6 btn3">выход</a>
<?php else: ?>
<a href="<?php echo e(route('login')); ?>" class="link-light fs-6 btn3">⎆ вход</a> ||
<a href="<?php echo e(route('reg')); ?>" class="link-light fs-6 btn3">регистрация</a>

<?php endif; ?>



</div><br>

<a href="<?php echo e(route('main')); ?>" class="btn btn-outline-light btn2"> Главная</a>
<a href="<?php echo e(route('add')); ?>" class="btn btn-outline-light btn2">Создать Пасту</a>
<?php if(Auth::Check()): ?>
<a href="<?php echo e(route('mypaste')); ?>" class="btn btn-outline-light btn2">Мои пасты</a>
<?php endif; ?>
<a href="<?php echo e(route('about')); ?>" class="btn btn-outline-light btn2">О проекте</a>
</div>
<div class="shapka-title"  style="">
    <b>[i]paste</b>
    <i style="font-size:12pt;"><br/>сервис публикации текстов и кодов</i>
</div>
</div>
<?php /**PATH D:\WAMP\vhosts\introzorn.co\paste\resources\views/head.blade.php ENDPATH**/ ?>