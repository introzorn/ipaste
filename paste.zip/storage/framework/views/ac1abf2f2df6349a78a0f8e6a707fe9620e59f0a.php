<?php $__env->startSection('main-title'); ?>О сервисе пасты<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="abstractcont">
<br><br>
    <div class="tablo" >
        <div class="row">
            <div class="col p404" style=""> </div>
            <div class="col-7" style="color:rgb(16, 0, 160)" ><b style="font-size: 90pt"> 404</b> <b style="font-size: 18pt;  white-space: nowrap;">страница не существует</b><br><br></div>

        </div>


    </div>

</div>

    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WAMP\vhosts\introzorn.co\paste\resources\views/p404.blade.php ENDPATH**/ ?>