<div class="footer">

Introzorn &copy; <?php echo e(date("Y")); ?>


</div>
<?php /**PATH D:\WAMP\vhosts\introzorn.co\paste\resources\views/footer.blade.php ENDPATH**/ ?>